# Zeitreise – Das 70er & 80er Quiz

Eigenständige, statische Quiz-Webseite mit **240 Fragen**: je 120 für die 70er und 80er, verteilt auf vier Kategorien und drei Schwierigkeitsgrade. Keine Fragen oder Formulierungen eines kommerziellen Spiels wurden übernommen.

## Schnellstart mit Docker Compose

```bash
docker compose up -d --build
```

Danach: `http://SERVER-IP:8088`

Port ändern: In `docker-compose.yml` links in `8088:80` die `8088` ersetzen.

## Ohne Docker

Den Inhalt von `app/` mit einem beliebigen statischen Webserver ausliefern. Ein lokaler Test geht z. B. so:

```bash
cd app
python3 -m http.server 8088
```

## Eigenschaften

- 120 Fragen pro Jahrzehnt, 30 je Kategorie
- Kategorien: Musik, Film & Fernsehen, Alltag & Technik, Zeitgeschehen & Sport
- Auswahl von Jahrzehnt, Kategorien, Schwierigkeit und Rundengröße
- Gemischte Runden und zufällige Reihenfolge
- Lösungen mit Erläuterung und Faktenquelle
- Lokale Statistik über `localStorage`
- Keine Anmeldung, keine Cookies, kein Tracking, kein Backend
- Responsiv für Smartphone, Tablet und Desktop

## Fragen bearbeiten

Die Daten liegen in `app/questions.js`. Jede Frage enthält:

```js
{
  id: 1,
  decade: "70er",
  category: "Musik",
  difficulty: "leicht",
  question: "...",
  answers: ["...", "...", "...", "..."],
  correct: "...",
  explanation: "...",
  source: "https://..."
}
```

Die `id` muss eindeutig bleiben. Zulässige Kategorien und Schwierigkeitswerte sollten unverändert geschrieben werden.

## Hinweis zu Fonts

Das Design lädt optional zwei Google Fonts. Ohne Internet greift es automatisch auf Systemschriften zurück; Spiellogik und Fragen funktionieren vollständig offline.
